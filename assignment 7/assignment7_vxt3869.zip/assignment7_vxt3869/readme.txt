Name: Vinayak Ravindra Tare
UTA ID: 1001453869

Running the code:
graphplan -o [operators_file] -f [facts_file]



For example:

graphplan -o hanoi_ops.txt -f hanoi_facts1.txt

graphplan -o puzzle_ops.txt -f puzzle_facts1.txt



Description: 

operator file contains definitions of actions.

facts file contains definitions of facts about the environment, 
including objects (and types for those objects), 
general predicates that are always true, initial state description, and goal description.
